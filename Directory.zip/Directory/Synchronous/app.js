var fs = require('fs');

fs.rmdirSync('stuff');
