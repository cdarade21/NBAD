var fs = require('fs');

fs.mkdirSync('stuff');
