var stuff = require('./stuff1');

console.log(stuff.counter(['shaun','crystal','ryu']));

console.log(stuff.adder(5,6));

console.log(stuff.adder(stuff.pi,5));
